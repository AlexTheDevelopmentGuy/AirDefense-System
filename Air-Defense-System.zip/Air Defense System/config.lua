Config = {}

Config.ZoneCenter  = vec3(-2048.0, 3132.0, 100.0)
Config.ZoneRadius  = 1200.0

Config.WarningTime = 8000
Config.BombFuse    = 3000

Config.NotifyType  = 'error'
Config.WarnText    = '⚠️ Restricted Airspace! Leave Fort Zancudo immediately.'
Config.LethalText  = '💣 Lethal force authorised.'
