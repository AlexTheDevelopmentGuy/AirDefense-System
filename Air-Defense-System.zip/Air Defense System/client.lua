local cfg = Config
if not cfg then
    print("^1[ERROR] Air Defense System: Configuration not loaded properly!^7")
    return
end

local alerted      = false
local warnedAt     = 0
local bombsPlaced  = false
local bombObjs     = {}

------------------------------------------------------------
-- helpers
------------------------------------------------------------
local function notify(msg)
    lib.notify({ title = 'Fort Zancudo AirDefense System', description = msg, type = cfg.NotifyType })
end

local function attachBomb(vehicle, boneName, offX, offY, offZ)
    local model = joaat('prop_bomb_01')
    lib.requestModel(model)

    local bomb  = CreateObject(model, 0.0, 0.0, 0.0, true, true, true)
    local bone  = GetEntityBoneIndexByName(vehicle, boneName)
    if bone == -1 then bone = 0 end

    AttachEntityToEntity(bomb, vehicle, bone, offX, offY, offZ, 0.0, 0.0, 0.0,
        true,  true,  false,  false,  2,  true)

    SetEntityCollision(bomb, false, false)
    bombObjs[#bombObjs + 1] = bomb
end

local function detonate(veh)
    local c = GetEntityCoords(veh)
    AddExplosion(c.x, c.y, c.z, 2, 100.0, true, false, 1.0)
    SetVehicleEngineHealth(veh, -4000.0)
end

------------------------------------------------------------
-- main thread
------------------------------------------------------------
CreateThread(function()
    while true do
        Wait(500)

        local ped = cache.ped
        if not DoesEntityExist(ped) then goto continue end

        if not IsPedInAnyPlane(ped) then
            alerted, bombsPlaced = false, false
            goto continue
        end

        local veh  = GetVehiclePedIsIn(ped, false)
        local dist = #(GetEntityCoords(veh) - cfg.ZoneCenter)

        if dist <= cfg.ZoneRadius then
            if not alerted then
                notify(cfg.WarnText)
                warnedAt, alerted = GetGameTimer(), true
            elseif not bombsPlaced and (GetGameTimer() - warnedAt) >= cfg.WarningTime then
                notify(cfg.LethalText)
                attachBomb(veh, 'wing_l', -0.6, -1.0, 0.1)
                attachBomb(veh, 'wing_r',  0.6, -1.0, 0.1)
                bombsPlaced = true

                CreateThread(function()
                    Wait(cfg.BombFuse)
                    detonate(veh)
                    for _,obj in ipairs(bombObjs) do DeleteEntity(obj) end
                    bombObjs = {}
                    alerted, bombsPlaced = false, false
                end)
            end
        else
            alerted, bombsPlaced = false, false
        end
        ::continue::
    end
end)
