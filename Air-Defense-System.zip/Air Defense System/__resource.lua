resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

name 'Air-Defense-System'
author 'A. Wright'
description 'Fort Zancudo Air-Defense System'
version '1.0.0'

dependency 'ox_lib'

shared_scripts { 'config.lua' }
client_scripts { '@ox_lib/init.lua', 'client.lua' }